import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { NavComponent } from '../nav/nav.component';
import { FormsModule } from '@angular/forms';
import { AddPropertyComponent } from './add-property.component'; // Import the standalone modal component
import { NgIf } from '@angular/common';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, NavComponent, FormsModule, AddPropertyComponent, NgIf],
  template: `
    <app-nav></app-nav>
    <div class="home-container">
      <div class="welcome-section">
        <h1>Welcome to House</h1>
        <p>Find your perfect home or list your property</p>
      </div>
      
      <div *ngIf="isLandlord">
        <div class="filters">
          <input [(ngModel)]="filterTitle" placeholder="Search by title" />
          <input [(ngModel)]="filterMaxRent" type="number" placeholder="Max Rent" />
          <select [(ngModel)]="filterPropertyType">
            <option value="">All Types</option>
            <option value="Apartment">Apartment</option>
            <option value="House">House</option>
            <option value="Condo">Condo</option>
          </select>
          <button (click)="applyFilters()">Search</button>
          <button (click)="resetFilters()">Reset</button>
        </div>

        <div *ngIf="properties.length < 1" class="no-results">
          <p>No properties available for landlord.</p>
          <button class="btn-add" (click)="isModalOpen = true">Add Property</button>
        </div>

        <button *ngIf="properties.length >= 1" class="btn-add-corner" (click)="isModalOpen = true">Add Property</button>

        <div *ngIf="filteredProperties.length === 0 && filterTitle.length > 0" class="no-results">
          <p>No properties found for your search.</p>
        </div>

        <div *ngIf="filteredProperties.length > 0" class="properties-section">
          <div class="properties-grid">
            <div *ngFor="let property of filteredProperties" class="property-card">
              <h3>{{ property.title }}</h3>
              <p *ngIf="property.address"><strong>Address:</strong> {{ property.address }}</p>
              <p *ngIf="property.rentPrice"><strong>Rent:</strong> {{ property.rentPrice | currency }}</p>
              <p *ngIf="property.propertyType"><strong>Type:</strong> {{ property.propertyType }}</p>
              <p *ngIf="property.description"><strong>Description:</strong> {{ property.description }}</p>
              <p *ngIf="property.status"><strong>Status:</strong> {{ property.status }}</p>
              <p *ngIf="property.bedrooms"><strong>Bedrooms:</strong> {{ property.bedrooms }}</p>
              <p *ngIf="property.furnished"><strong>Furnished:</strong> {{ property.furnished }}</p>
              <p><strong>Parking Included:</strong> <span [ngClass]="{'tick-icon': property.parkingIncluded, 'cross-icon': !property.parkingIncluded}"></span></p>
              <p><strong>Pets Allowed:</strong> <span [ngClass]="{'tick-icon': property.petsAllowed, 'cross-icon': !property.petsAllowed}"></span></p>
              <p *ngIf="property.additionalNotes"><strong>Additional Notes:</strong> {{ property.additionalNotes }}</p>
            </div>
          </div>
        </div>
      </div>
      
      <div class="features-grid" *ngIf="!isLandlord">
        <div class="feature-card" (click)="navigateTo('/properties')">
          <h3>Browse Properties</h3>
          <p>Explore available properties for rent</p>
        </div>
        
        <div class="feature-card" (click)="navigateTo('/rentals')">
          <h3>My Rentals</h3>
          <p>Manage your current rentals</p>
        </div>
        
        <div class="feature-card" (click)="navigateTo('/payments')">
          <h3>Payments</h3>
          <p>View and manage your payments</p>
        </div>
      </div>
    </div>

    <app-add-property 
      *ngIf="isModalOpen" 
      (closeModal)="isModalOpen = false" 
      (propertyAdded)="loadProperties(userId)"></app-add-property>
  `,
  styles: [`
    .home-container {
      padding: 2rem;
      background-color: #f0f2f5;
      min-height: 100vh;
      font-family: 'Arial', sans-serif;
    }
    
    .welcome-section {
      text-align: center;
      margin-bottom: 3rem;
      color: #333;
    }
    
    .welcome-section h1 {
      font-size: 2.5rem;
      margin-bottom: 0.5rem;
      color: #007bff;  /* Primary color */
    }

    .filters {
      display: flex;
      flex-wrap: wrap; /* Allow wrapping for responsiveness */
      justify-content: space-between;
      align-items: center;
      margin-bottom: 2rem;
    }
    
    .filters input,
    .filters select {
      padding: 0.8rem;
      border: 1px solid #ccc;
      border-radius: 4px;
      width: calc(25% - 1rem); /* Updated for better responsiveness */
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
      transition: border 0.3s;
    }

    .filters input:focus,
    .filters select:focus {
      border-color: #007bff;
      outline: none;
    }

    .filters button {
      padding: 0.6rem 1.3rem;
      background-color: #007bff;
      color: white;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      margin-left: 10px;
      transition: background-color 0.3s, transform 0.2s;
    }
    
    .filters button:hover {
      background-color: rgba(0, 123, 255, 0.8);
      transform: translateY(-2px); /* Subtle lift effect */
    }

    .no-results {
      text-align: center;
      color: #999;
      margin: 2rem 0;
    }
    
    .btn-add,
    .btn-add-corner {
      padding: 1rem 2rem;
      background-color: #007bff;
      color: white;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      transition: background-color 0.3s, transform 0.2s;
    }

    .btn-add:hover,
    .btn-add-corner:hover {
      background-color: rgba(0, 123, 255, 0.8);
      transform: translateY(-2px);
    }

    .properties-section {
      margin-top: 2rem;
    }
    
    .properties-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
      gap: 1rem;
    }
    
    .property-card {
      background-color: white;
      padding: 1.5rem;
      border-radius: 8px;
      box-shadow: 0 1px 3px rgba(0, 0, 0, 0.2);
      transition: transform 0.2s;
    }

    .property-card:hover {
      transform: translateY(-5px);  /* Lift effect on hover */
    }
    
    .property-card h3 {
      margin: 0 0 1rem;
      color: #007bff;
    }

    .property-card p {
      margin: 0.4rem 0;
      line-height: 1.5;
    }

    .features-grid {
      display: flex;
      justify-content: space-around;
      margin-top: 2rem;
    }

    .feature-card {
      background-color: white;
      padding: 2rem;
      border-radius: 8px;
      border: 1px solid #ddd;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
      cursor: pointer;
      transition: transform 0.2s;
    }

    .feature-card:hover {
      transform: translateY(-5px);
      box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);  /* Enhanced shadow on hover */
    }

    @media (max-width: 768px) {
      .filters input,
      .filters select {
        width: 48%; /* Better width on smaller screens */
      }
    
      .filters button {
        width: 100%;
        margin: 0.5rem 0;
      }
    }
    .tick-icon::before {
      content: '✔️';
      filter: invert(1);
      color: green;
    }
    .cross-icon::before {
      content: '❌';
      color: red;
    }
  `]
})
export class HomeComponent implements OnInit {
  isLandlord = false;
  userId: number = 0;
  properties: any[] = [];
  filteredProperties: any[] = [];
  filterTitle: string = '';
  filterMaxRent: number | null = null;
  filterPropertyType: string = '';
  isModalOpen = false; // Track if the modal is open

  constructor(private router: Router, private http: HttpClient) {}

  ngOnInit() {
    const user = localStorage.getItem('user');
    if (user) {
      const userObj = JSON.parse(user);
      this.userId = userObj.userId; 
      if (userObj.role === 'landlord') {
        this.isLandlord = true;
        this.loadProperties(this.userId);
      }
    }
  }

  loadProperties(landlordId: number) {
    this.http.get<any[]>(`http://localhost:5216/api/Properties/landlord/${landlordId}`)
      .subscribe({
        next: (response) => {
          this.properties = response;
          this.filteredProperties = [...this.properties]; // Set filtered properties once data is loaded
        },
        error: (error) => {
          console.error('Error loading properties:', error);
        }
      });
  }

  applyFilters() {
    this.filteredProperties = this.properties.filter(property => {
      return (!this.filterTitle || property.title.toLowerCase().includes(this.filterTitle.toLowerCase())) &&
             (!this.filterMaxRent || property.rentPrice <= this.filterMaxRent) &&
             (!this.filterPropertyType || property.propertyType === this.filterPropertyType);
    });
  }

  resetFilters() {
    this.filterTitle = '';
    this.filterMaxRent = null;
    this.filterPropertyType = '';
    this.filteredProperties = [...this.properties]; // Reset to all properties
  }

  navigateTo(path: string) {
    this.router.navigate([path]);
  }
}