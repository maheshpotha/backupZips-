import { Component, EventEmitter, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';

@Component({
  selector: 'app-add-property',
  standalone: true,
  template: `
    <div class="modal-overlay" (click)="onClose()">
      <div class="modal" (click)="$event.stopPropagation()">
        <button class="close-button" (click)="onClose()">X</button>
        <h2>Add Property</h2>
        <form [formGroup]="propertyForm" (ngSubmit)="onSubmit()">
          <div class="form-group">
            <label for="title">Title:</label>
            <input id="title" type="text" formControlName="title" required />
          </div>
          <div class="form-group">
            <label for="rentPrice">Rent Price:</label>
            <input id="rentPrice" type="number" formControlName="rentPrice" required />
          </div>
          <div class="form-group">
            <label for="address">Address:</label>
            <input id="address" type="text" formControlName="address" required />
          </div>
          <div class="form-group">
            <label for="bedrooms">Bedrooms:</label>
            <input id="bedrooms" type="number" formControlName="bedrooms" required />
          </div>
          <div class="form-group">
            <label for="description">Description:</label>
            <textarea id="description" formControlName="description"></textarea>
          </div>
          <div class="form-group">
            <label for="propertyType">Property Type:</label>
            <select id="propertyType" formControlName="propertyType" required>
              <option *ngFor="let type of propertyTypes" [value]="type">{{ type }}</option>
            </select>
          </div>
          <div class="form-group">
            <label for="status">Status:</label>
            <select id="status" formControlName="status" required>
              <option *ngFor="let status of statuses" [value]="status">{{ status }}</option>
            </select>
          </div>
          <div class="form-group">
            <label for="furnished">Furnished:</label>
            <select id="furnished" formControlName="furnished" required>
              <option *ngFor="let level of furnishedLevels" [value]="level">{{ level }}</option>
            </select>
          </div>
          <div class="form-group checkbox">
            <input type="checkbox" formControlName="parkingIncluded" id="parkingIncluded" />
            <label for="parkingIncluded">Parking Included</label>
          </div>
          <div class="form-group checkbox">
            <input type="checkbox" formControlName="petsAllowed" id="petsAllowed" />
            <label for="petsAllowed">Pets Allowed</label>
          </div>
          <div class="button-group">
            <button type="submit" [disabled]="propertyForm.invalid">Add Property</button>
            <button type="button" (click)="onClose()">Cancel</button>
          </div>
        </form>
      </div>
    </div>
  `,
  styles: [`
    .modal-overlay {
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background-color: rgba(0, 0, 0, 0.5);
      display: flex;
      justify-content: center;
      align-items: center;
    }
    .modal {
      background-color: white;
      padding: 20px;
      border-radius: 8px;
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.2);
      max-width: 350px; /* Reduced max-width */
      width: 90%;
      position: relative;
    }
    .close-button {
      position: absolute;
      top: 10px;
      right: 10px;
      padding: 5px 10px;
      border: none;
      background-color: transparent;
      cursor: pointer;
      font-size: 18px;
      font-weight: bold;
    }
    .form-group {
      margin-bottom: 15px; /* Increased space between form groups */
    }
    label {
      display: block;
      margin-bottom: 5px;
      font-weight: bold;
    }
    input, select, textarea {
      width: 100%;
      padding: 8px;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
    }
    .checkbox {
      display: flex;
      align-items: center;
      margin-bottom: 15px; /* Increased space between checkbox groups */
    }
    .checkbox label {
      margin-left: 8px; /* Added spacing between checkbox and label */
    }
    .checkbox input[type="checkbox"] {
      margin-right: 5px; /* Added spacing between checkbox and label */
    }
    .button-group {
      display: flex;
      justify-content: space-between;
      margin-top: 20px;
    }
    button {
      padding: 10px 20px;
      background-color: #4CAF50;
      color: white;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }
    button:disabled {
      background-color: #ccc;
      cursor: not-allowed;
    }
    @media (max-width: 350px) {
      .modal {
        width: 95%;
      }
    }
  `],
  imports: [CommonModule, ReactiveFormsModule]
})
export class AddPropertyComponent {
  propertyForm: FormGroup;
  propertyTypes = ['Apartment', 'House', 'Condo'];
  statuses = ['Available', 'Rented'];
  furnishedLevels = ['None', 'Semi', 'Fully'];
  @Output() closeModal = new EventEmitter<void>();
  @Output() propertyAdded = new EventEmitter<void>();

  constructor(private fb: FormBuilder, private http: HttpClient) {
    this.propertyForm = this.fb.group({
      title: ['', Validators.required],
      rentPrice: ['', [Validators.required, Validators.min(0)]],
      address: ['', Validators.required],
      bedrooms: ['', [Validators.required, Validators.min(1)]],
      description: [''],
      propertyType: ['', Validators.required],
      status: ['', Validators.required],
      furnished: ['', Validators.required],
      parkingIncluded: [false],
      petsAllowed: [false],
    });
  }

  onSubmit() {
    const landlordId = JSON.parse(localStorage.getItem('user') || '{}').userId || null;

    if (!landlordId) {
      console.error("Landlord ID not found in local storage.");
      return;
    }

    const propertyData = { ...this.propertyForm.value, landlordId };

    this.http.post('http://localhost:5216/api/Properties', propertyData).subscribe({
      next: response => {
        console.log('Property added successfully', response);
        this.propertyAdded.emit();
        this.onClose();
      },
      error: error => {
        console.error('Error adding property:', error);
        // Add user-friendly error handling here (e.g., display an error message)
      }
    });
  }

  onClose() {
    this.closeModal.emit();
  }
}