import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-nav',
  standalone: true,
  imports: [CommonModule],
  template: `
    <nav class="navbar">
      <div class="nav-brand">House</div>
      <div class="nav-links">
        <div class="profile" (click)="toggleProfileMenu()">
          <img src="path/to/profile-icon.png" alt="Profile Icon" class="profile-icon">
          <span class="profile-name">{{ userName }}</span>
          <div class="profile-menu" *ngIf="isProfileMenuOpen">
            <a (click)="navigateTo('/properties')" class="profile-menu-item">Properties</a>
            <a (click)="navigateTo('/rentals')" class="profile-menu-item">My Rentals</a>
            <a (click)="navigateTo('/payments')" class="profile-menu-item">Payments</a>
          </div>
        </div>
        <button class="btn-logout" (click)="logout()">Logout</button>
      </div>
    </nav>
  `,
  styles: [`
    .navbar {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 1rem 2rem;
      background-color: #fff;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    .nav-brand {
      font-size: 1.5rem;
      font-weight: bold;
      color: #007bff;
    }
    .nav-links {
      display: flex;
      gap: 2rem;
      align-items: center;
    }
    .nav-link {
      color: #333;
      text-decoration: none;
      cursor: pointer;
    }
    .nav-link:hover {
      color: #007bff;
    }
    .profile {
      position: relative;
      display: flex;
      align-items: center;
      cursor: pointer;
    }
    .profile-icon {
      width: 32px;
      height: 32px;
      border-radius: 50%;
      margin-right: 0.5rem;
    }
    .profile-name {
      color: #333;
    }
    .profile-menu {
      position: absolute;
      top: 100%;
      right: 0;
      background-color: #fff;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
      border-radius: 4px;
      overflow: hidden;
      z-index: 1000;
    }
    .profile-menu-item {
      display: block;
      padding: 0.5rem 1rem;
      color: #333;
      text-decoration: none;
      white-space: nowrap;
    }
    .profile-menu-item:hover {
      background-color: #f0f4f8;
    }
    .btn-logout {
      padding: 0.5rem 1rem;
      background-color: #dc3545;
      color: white;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }
    .btn-logout:hover {
      background-color: #c82333;
    }
  `]
})
export class NavComponent implements OnInit {
  userName = '';
  isProfileMenuOpen = false;

  constructor(private router: Router, private authService: AuthService) {}

  ngOnInit() {
    const user = localStorage.getItem('user');
    if (user) {
      const userObj = JSON.parse(user);
      this.userName = userObj?.name;
    }
  }

  navigateTo(path: string) {
    this.router.navigate([path]);
  }

  logout() {
    this.authService.logout();
    this.router.navigate(['/auth']);
  }

  toggleProfileMenu() {
    this.isProfileMenuOpen = !this.isProfileMenuOpen;
  }
}