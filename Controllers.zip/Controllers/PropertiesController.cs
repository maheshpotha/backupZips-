﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using AutoMapper;
using HouseRentalApplication.Data;
using HouseRentalApplication.Models.Entity;
using HouseRentalApplication.Models.DTOs;

namespace HouseRentalApplication.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PropertiesController : ControllerBase
    {
        private readonly ApplicationDbContext _context;
        private readonly IMapper _mapper;

        public PropertiesController(ApplicationDbContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        // POST: api/Properties
        [HttpPost]
        public async Task<IActionResult> CreateProperty([FromBody] PropertyDto propertyDto)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var property = _mapper.Map<Property>(propertyDto);
            _context.Properties.Add(property);
            await _context.SaveChangesAsync();

            var createdPropertyDto = _mapper.Map<PropertyDto>(property);
            return CreatedAtAction(nameof(GetPropertyById), new { id = property.PropertyId }, createdPropertyDto);
        }

        // GET: api/Properties
        [HttpGet]
        public async Task<ActionResult<IEnumerable<PropertyDto>>> GetProperties()
        {
            var properties = await _context.Properties.Include(p => p.Landlord).ToListAsync();
            var propertyDtos = _mapper.Map<List<PropertyDto>>(properties);
            return Ok(propertyDtos);
        }

        // GET: api/Properties/{id}
        [HttpGet("{id}")]
        public async Task<ActionResult<PropertyDto>> GetPropertyById(int id)
        {
            var property = await _context.Properties.Include(p => p.Landlord)
                                    .FirstOrDefaultAsync(p => p.PropertyId == id);

            if (property == null)
            {
                return NotFound();
            }

            var propertyDto = _mapper.Map<PropertyDto>(property);
            return Ok(propertyDto);
        }

        // GET: api/Properties/landlord/{landlordId}
        [HttpGet("landlord/{landlordId}")]
        public async Task<ActionResult<IEnumerable<PropertyDto>>> GetPropertiesByLandlordId(int landlordId)
        {
            var properties = await _context.Properties
                .Where(p => p.LandlordId == landlordId)
                .Include(p => p.Landlord)
                .ToListAsync();

            if (properties == null || !properties.Any())
            {
                return NotFound("No properties found for this landlord.");
            }

            var propertyDtos = _mapper.Map<List<PropertyDto>>(properties);
            return Ok(propertyDtos);
        }

        // PUT: api/Properties/{id}
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateProperty(int id, [FromBody] PropertyDto propertyDto)
        {
            if (id != propertyDto.PropertyId || !ModelState.IsValid)
            {
                return BadRequest();
            }

            var property = await _context.Properties.FindAsync(id);
            if (property == null)
            {
                return NotFound();
            }

            _mapper.Map(propertyDto, property);
            _context.Entry(property).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!PropertyExists(id))
                {
                    return NotFound();
                }
                throw;
            }

            return NoContent();
        }

        // DELETE: api/Properties/{id}
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteProperty(int id)
        {
            var property = await _context.Properties.FindAsync(id);
            if (property == null)
            {
                return NotFound();
            }

            _context.Properties.Remove(property);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool PropertyExists(int id)
        {
            return _context.Properties.Any(e => e.PropertyId == id);
        }
    }
}